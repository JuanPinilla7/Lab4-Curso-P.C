![Logo UCN](60x60-ucn-negro.png)
# Laboratorio 04: Cálculo de SK

**Alumnos:** Juan Pinilla, Ignacio Garín

**Docentes:** Juan Bekios, Diego Valdivia

**Ayudante:** Cristian Galleguillos 

## 1. Introducción 

**Definición del problema**

Dado un conjunto de archivos de texto que contienen coordenadas de peatones mientras transitan por un pasillo con puertas de diferentes medidas, se requiere determinar el valor Sk, y junto con ello la creación de un gráfico del tipo histograma que permita discernir la distribución de las velocidades, y además, un gráfico de dispersión que permita visualizar la correlación existente entre el valor Sk y la velocidad del peatón. Además obtenga estadísticos útiles, como velocidad promedio y valor Sk promedio.

### 1.1 Justificación

El análisis del valor Sk (distancia promedio entre peatones), junto con la creación de un histograma para las velocidades y un gráfico de dispersión que relaciona el valor Sk con la velocidad, permitirá entender mejor la circulación de peatones en pasillos con puertas de diferentes tamaños. Estas visualizaciones y estadísticas proporcionarán información crucial para optimizar el diseño de espacios públicos, mejorar la eficiencia del flujo de personas y garantizar su seguridad.

### 1.2 Objetivos 

**Objetivo General**

Obtener el valor Sk a partir de un archivo de texto.

**Objetivos específicos**

1. Procesar información de una fuente de texto.

2. Calcular SK para cada instante.

3. Calcular velocidad para cada instante.

4. Generar gráfico de histograma (Velocidad vs frecuencia) y de dispersión (Velocidad del peatón vs Valor Sk)

5. Analizar los gráficos obtenidos en su respectivo contexto.

6. Subir gráfico de dispersión a la web.

## 2. Marco teórico 

**Python**: Lenguaje de programación de alto nivel, ampliamente utilizado.

**Visual Studio**: Editor de código fuente altamente popular, desarrollado por Microsoft. Es una herramienta de programación de código abierto que admite múltiples lenguajes de programación y proporciona una amplia gama de características útiles.

**Librerías utilizadas**:
- Pandas: Librería de Python especializada en el manejo y análisis de estructuras de datos.
- NumPy: Biblioteca para cálculos numéricos y manipulación de arreglos multidimensionales.
- Matplotlib: Biblioteca para crear gráficos y visualizaciones de datos en diversas dimensiones.
- Sreamlit: Herramienta de código abierto que facilita la creación rápida de aplicaciones web interactivas para visualizar datos usando Python.
- Scipy: Librería de Python utilizada para computación científica y análisis numérico.

## 3. Materiales y métodos

Se usó un dataset de nombre "UNI_CORR_500_01". El archivo de texto tiene 5 columnas y más de 25.000 filas. Describe la ubicación de las personas usando sus coordenadas en diferentes frames. Las posiciones están en metros. La cámara captó imágenes a 25 fps.

El experimento busca calcular el valor SK, el cual es un promedio de la distancia de un peatón respecto a los demás en un radio dado. Para lograr esto, se debe seguir una serie de pasos.

Primeramente se capturó la información en un dataframe como ya se ha hecho anteriormente. El algoritmo es iterativo, inicia guardando información clave como el peatón y el frame observado, para luego formar un sub dataframe de todos los peatones que aparecen en ese mismo frame. Usando el módulo KDTree de Scipy es posible generar una "vecindad", se le entrega un punto de referencia (peatón observado) y un radio, y retornará un array con todos los peatones alrededor del punto fijo dentro de ese radio, llamados como "vecinos". Para cada vecino se calcula una distancia euclidiana respecto al peatón observado y una vez recorrida toda la vecindad se calcula el promedio de estas distancias, el valor "SK". Este proceso se realiza para cada peatón en cada frame, obteniendo más de 25.000 registros.

Una vez fuera del ciclo, se crea una nueva columna con los valores de SK y otras dos correspondientes a distancia y velocidad del peatón en dicho instante, de la misma forma como se hizo en laboratorios pasados. Hay control de outliers, para aquellos peatones que se encontraban alejados (sin vecindad) el SK arrojaba error de división por cero, el cual fue reemplazado por el promedio de los datos. Algo similar se realizó con las velocidades, el primer y el último frame de cada peatón presenta dificultades de cálculo, para lo cual se reemplazó con el promedio.

Finalmente, se ilustra un gráfico de dispersión entre el valor calculado SK y la velocidad real de cada peatón, además del histograma de las distribuciones de velocidad.

El gráfico SK vs Velocidad fue subido a un sitio web interactivo, donde se puede modificar el radio de la vecindad y observar como varían los resultados.

LINK:
https://laboratoriosk.streamlit.app/

## 4. Resultados obtenidos

La ejecución del algoritmo permite visualizar los valores de SK obtenidos en contraste con sus respectivas velocidades.

![SK vs Velocidad](SK1.png)

Además se muestra el histograma de la distribución de velocidades.

![Velocidades](velocidad1lab4.png)

El promedio del cálculo SK es de 1.91, es decir, que existe una distancia promedio de 1.91 metros entre personas a través del pasillo. Esto se relaciona con la velocidad promedio de 1.47 mts/s, ya que de acuerdo a cuantas personas estén alrededor un peatón variará el ritmo de su paso. En el gráfico de dispersión se aprecia que hay menos puntos en el límite superior del SK, pero estos tienen una velocidad cercana o mayor al promedio, esto es debido a que tienen más libertad para moverse y aceleran el paso, en cambio si observamos la zona central de la gráfica, cercana al promedio de 1.9 de SK, hay mucha dispersión pero en general las velocidades son menores, porque hay menos espacio para desplazarse. Las variaciones no son radicales, esto puede deberse a que los rangos de SK y velocidad son acotados, y al factor aleatorio de trabajar con peatones diferentes.

El histograma de velocidades muestra como se distribuyen, de forma un poco similar a una campana con media de 1.47 pero sesgada a la izquierda (menor velocidad).

## 5. Conclusiones

Luego de realizar el laboratorio se pudieron visualizar gráficos de dispersión e histogramas para el cálculo de SK y velocidad de los peatones, además de desplegar el algortimo en un sitio web.

Se concluye que un valor de SK más alto se traduce generalmente en una velocidad de circulación más rápida, ya que SK es un promedio de las distancias entre un peatón observado y las personas que estén dentro de un radio de cercanía, por lo que a un valor mayor, más libertad de desplazamiento tendrán las personas.

El estudio de los peatones tiene un amplio espectro de factores a considerar y una gran utilidad, desde toma de decisiones de marketing, maximización de recursos espaciales, minimización de tiempo en un sistema o satisfaccción de los clientes, por lo que este laboratorio junto con los demás desarrollados serán de utilidad en la vida profesional.
